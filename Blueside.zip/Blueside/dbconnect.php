<?php 
// isi nama host, username mysql, dan password mysql anda
$conn = mysqli_connect("localhost","root","","Blueside");

if(!$conn){
	echo "gagal konek database menn";
} else {
	
};

?>